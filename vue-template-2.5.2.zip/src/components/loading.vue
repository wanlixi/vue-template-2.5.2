<template>
	<div class="pupop" v-show="show">
		<img class="loading_img" src="../assets/img/common/loading.gif" />
	</div>
</template>
<script>
export default {
	props: ['show']
}
</script>
<style lang="stylus" scoped>
	.loading_img 
		width 16%
</style>