<!-- 
	2017-11-16 create by wanlixin
	desc: carousel component only use image
 -->
<template>
	<div class="swiper-container"
		@touchstart="touchstart($event)"
  	@touchmove="touchmove($event)"
  	@touchend="touchend">
    <div class="swiper-wrapper"
    	:style="{width: wrapperWidth, minWidth: widthScreen * 4 + 'px', transform: wrapperTransform}">
    	<div class="swiper-slide"
      	v-for="(item, index) in banner_list"
      	:key="item.SORT"
      	:class="{
					'current_slide': current === index,
					'sbiling_slide': current === index - 1 || current === index + 1,
      	}"
      	:style="{width: widthScreen + 'px'}">
          <video class="swiper-video" 
          	v-if="item.MEDIA_TYPE == 1" 
          	:src="item.BANNER_URL"
          	poster="http://xxx.com/vedio_andriod.jpg"></video>
        	<img 
						v-if="item.MEDIA_TYPE == 0" 
        		:src="item.BANNER_URL" />
      </div>
	  </div>
    <div class="swiper-pagination" v-if="pagination">
    	<span 
    		v-for="(item, index) in banner_list.length"
    		:key="index"
    		@click="clickPage(index)"
    		:class="['page', current === index ? 'paging' : '']"></span>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
	export default {
		data () {
			return {
				selected: 0,
				wrapperWidth: '',
				sx: 0,
				sy: 0,
				ex: 0,
				ey: 0,
				dx: 0,
				dy: 0,
				lx: 50,
				ly: 80,
				current: 0,
				wrapperTransform: '',
			}
		},
		computed: mapGetters(['widthScreen']),
		props: ['banner_list', 'pagination'],
		updated () {
			this.wrapperWidth = this.widthScreen * this.banner_list.length + 'px';
		},
		methods: {
			touchstart (e) {
				e = e || window.event;
				this.sx = e.touches[0].pageX;
				this.sy = e.touches[0].pageY;
			},
			touchmove (e) {
				e = e || window.event;
				this.ex = e.touches[0].pageX;
				this.ey = e.touches[0].pageY;
			},
			touchend () {
				this.dx = this.ex - this.sx;
				this.dy = this.ey - this.sy;
				// 左滑
				if (this.ex && Math.abs(this.dy) < this.ly && Math.abs(this.dx) > this.lx && this.dx < -this.lx) {
					this.current++;
					this.current > this.banner_list.length - 1 && (this.current = 0)
					this.swiper()
				}

				// 右滑
				if (this.ex && Math.abs(this.dy) < this.ly && Math.abs(this.dx) > this.lx && this.dx > this.lx) {
					this.current--;
					this.current < 0 && (this.current = this.banner_list.length - 1)
					this.swiper()
				}
				this.dx = this.sx = this.ex = 0;
				this.dy = this.sy = this.ey = 0;

			},
			swiper () {
				this.wrapperTransform = `translateX(-${this.current * this.widthScreen}px)`
			},
			clickPage (index) {
				this.current = index;
				this.swiper();
			},
		}
	}
</script>