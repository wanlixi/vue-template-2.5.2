<template>
	<pupop v-show="pupop_success_state_child">
		<div class="cont cont_suc">
      <Icon type="ios-checkmark-outline" size="48" color="#09BB07"></Icon>
      <p class="cont_suc_title" style="color:#09BB07">提交成功</p>
      <button class="pupop_btn" @click="onSure">确定</button>
    </div>
	</pupop>
</template>
<script>
import pupop from './pupop'
export default {
	components: {pupop},
	data () {
		return {
			pupop_success_state_child: false
		}
	},
	props: {
		pupop_success_state: false
	},
	mounted () {
		this.pupop_success_state_child = this.pupop_success_state
	},
	methods: {
		onSure () {
			this.pupop_success_state_child = false;
			this.$emit('onSure')
		}
	}
}
</script>
<style lang="stylus" scoped>
	
</style>