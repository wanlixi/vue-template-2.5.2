<!-- Create by wanlixin 2017-11-22 -->
<template>
	<div class="pupop" @touchmove="prevent">
		<div class="content">
			<slot></slot>
		</div>
	</div>
</template>
<script>
export default {
  methods: {
  	prevent (e) {
  		e.preventDefault()
  	}
  }
}
</script>
<style lang="stylus" scoped>
@import '~@/assets/css/common/var'
.content 
	position relative
	width 6.22rem; // 311px
	min-height 5.2rem; // 260px
	height auto
	background #fff
.cont 
	min-height inherit
	height 100%
	display flex
	flex-flow column wrap
	justify-content space-around
	align-items center
	padding 7% 0
	
.cont_suc_title
	font-size .32rem; // 16px
.cont_suc_desc
	font-size .28rem; // 14px
.cont_suc .ivu-icon
	font-weight 700
.pupop_btn
	display block
	line-height .8rem; // 40px
	text-align center
	width 5.42rem; // 271px
	height .8rem; // 40px
	background $commonYellow
	color #fff
	border none
	font-size .32rem/* 16px */
</style>
