// 初始化样式和全局样式
// import './css/common/normalize.css'
import './css/common/var.styl'
import './css/common/function.styl'
import './css/common/global.styl'
import flexible from 'flexible.js'
flexible(750, 640)

// 修改第三方UI库样式
