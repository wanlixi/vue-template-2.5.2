// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import router from './router';
// import './router/common-components';
import './assets/lib';
// import store from './store';
import './api/config';
import './api/mock';
import api from './api';
// import baiduMap from 'vue-baidu-map';

// 微信分享菜单按钮控制
// import { controlShare } from './assets/js/utils'
// controlShare('hideOptionMenu')

// 百度地图 开发者KEY
// let ak = 'PuzhG7k3qNXjP3OLDoFVCpznE4QTt2bl';
// Vue.use(baiduMap, {ak});

Vue.config.productionTip = false;
Vue.prototype.fetch = api;

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  // store,
  template: '<App/>',
  components: { App }
})
