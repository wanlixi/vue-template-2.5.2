<template>
  <div class="index">
    <ul>
      <li v-for="(item, index) in list" v-bind:key="index">{{item}}</li>
    </ul>
  </div>
</template>
<script>
export default {
  data () {
    return {
      list: [
        1,1,1
      ]
    }
  }
}
</script>
<style lang="stylus" scoped>
  @import '~@/assets/css/index.styl'
  div
    width 2rem; /* 100px */
</style>
