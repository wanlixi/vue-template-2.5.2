<!-- 
【功能描述】：布局模板
 -->
<template>
  <div class="app">
    <!--<v-header></v-header> -->
    <div class="main">
      <keep-alive>
        <router-view v-if="$route.meta.keepAlive"></router-view>
      </keep-alive>
      <router-view v-if="!$route.meta.keepAlive"></router-view>
    </div>
    <!--<v-footer></v-footer> -->
    <!--<go-top></go-top>-->
  </div>
</template>