<template>
	<div class="err">
		<img class="combind_up" src="../../assets/img/404/Combined Shape012X.png" />
		<div class="content">
			<h1>404</h1>
			<p class="customer">尊敬的客户，页面出了点小插曲</p>
			<p class="suggest">建议您重新登录</p>
		</div>
		<img class="combind_down" src="../../assets/img/404/Combined Shape022X.png" />
	</div>
</template>
<script>
	
</script>
<style lang="stylus" scoped>
@import '~@/assets/css/common/var'
.err
	display flex
	flex-flow column wrap
	align-items center
	justify-content space-between
	width 100%
	height 100%
	text-align center
	background #e2d495 url('../../assets/img/404/BG2X.png') left bottom / 7.5rem/* 375px */ 5.04rem/* 252px */ no-repeat
.combind_up,.combind_down
	width 1.22rem/* 61px */

h1 
	margin 0
	font-size .96rem/* 48px */
	color $commonYellow
.customer
	font-size .36rem/* 18px */
	color $commonYellow
.suggest
	font-size .48rem/* 24px */
</style>