
import * as types from './types'

const mutations = {
  // [types.GET_USER_INFO]: (state, res) => state.userInfo = res
}
export default mutations
