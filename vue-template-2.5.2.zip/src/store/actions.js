import * as types from './types'
import { formatDate } from '@/assets/js/utils'
import api from '../api'
// import { Message } from 'iview'

export default {
	// GET_USER_INFO: ({commit}, {certi_code, certi_type, name, mobile, openid}) => api.getCusByCodeType({certi_code, certi_type, name, mobile, openid}).then(res => res.retCode === '0000'),
}
