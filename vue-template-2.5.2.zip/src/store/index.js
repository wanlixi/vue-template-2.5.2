
import Vue from 'vue'
// import Vuex from 'vuex'
import mutations from './mutations'
import actions from './actions'
import getters from './getters'

// Vue.use(Vuex)
let width = document.body.clientWidth;
const state = {
  widthScreen: width,
  userInfo: {}
}

const debug = process.env.NODE_ENV == 'development'

// export default new Vuex.Store({
//   state,
//   actions,
//   mutations,
//   getters,
//   strict: debug
//   // plugins: [debg ? ['createLogger()'] : []],
//   // store分模块 aaa和bbb里面分别包含state/mutations/actions
//   // modules: {a:aaa,b:bbb},
// })