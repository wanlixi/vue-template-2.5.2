// import Vue from 'vue'
/** 公共头 ***/
// import VHeader from './components/header/header.vue'
// Vue.component('VHeader', VHeader)
// import VNav from 'components/nav/nav.vue'
// Vue.component('VNav', VNav)
/** 公共头 ***/
/** 公共尾 ***/
// import { Icon, Message } from 'iview'
// 按需引入
// import Icon from 'iview/src/components/icon'
// import Message from 'iview/src/components/message'
// import iview from 'iview'
// import 'iview/dist/styles/iview.css';    // 使用 CSS
// Vue.use(iview)
/** 公共弹窗 ***/
// import loading from '../components/loading.vue'
// Vue.component('loading', loading)
/** 公共尾 ***/
/** 飘浮物向上箭头 ***/
// import GoTop from './components/gotop/gotop.vue'
// Vue.component('GoTop', GoTop)
// Vue.component('Icon', Icon)
// Vue.component('Message', Message)
// Vue.prototype.msg = Message
