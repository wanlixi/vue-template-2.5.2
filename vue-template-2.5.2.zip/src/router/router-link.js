import Layout from '../module/layout'

function loadView (loader) {
  let endLoading = function endLoading (resolve) {
    return function end (component) {
      resolve(component)
    }
  }
  // before load
  return function load (resolve) {
    loader(endLoading(resolve))
  }
}

const routes = [
  {
    path: '/',
    component: Layout,
    children: [
      {
        path: '/',
        name: 'index',
        component: loadView(loaded => require(['../module/index/index'], loaded)),
        meta: {keepAlive: true, title: 'index '}
      }, {
        path: '*',
        component: loadView(loaded => require(['../module/not_found/not_found'], loaded)),
        meta: {keepAlive: true, title: '页面出错啦'}
      }
    ]
  }
]

export default routes
