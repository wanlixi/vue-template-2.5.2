// BACK-END DATA REQUEST CENTER

import fetch from './config'

export default {
  // getWxAuthInfo : url => fetch(`/user/getWxAuthInfo?url=${url}`),
  // getByCusIdAndDate: (com_id, date, cus_id = 1) => fetch('reserve/getByCusIdAndDate', 'post', {com_id, cus_id, date})
}
