// DEV_ENV API CENTER

import Mock from 'mockjs'
import { baseURL } from './config'

// 太平乐享养老社区 banner
Mock.mock('http://xxx.com/community', 'get',
  {
    'success': true,
    'retCode': '0000',
    'retMsg': '执行成功!',
    'data': [
      {
        'INTRO': '说明1',
        'BANNER_URL': 'http://xxx.com/1510540259.jpg',
        'BANNER_NAME': 'banner1',
        'MEDIA_TYPE': 0
      }
    ]
  }

)
// 太平乐享养老社区 获取全部社区接口
Mock.mock('http://xxx.com/community', 'post',
  {
    'success': true,
    'retCode': '0000',
    'retMsg': '执行成功!',
    'data': [
      {
        'SORT': 1, // 排序
        'COVER_PIC': 'http://xxx.com/wutongrenjia.jpg', // 封面图
        'CREATE_TIME': 1510122154000, // 创建时间
        'ADDRESS': '上海市浦东新区西藏路1999号', // 地址
        'INTRO': '社区亮点1', // 社区亮点
        'ID': 1,
        'COMMUNITY_NAME': '', // 社区名称
        'STATUS': 0  // 0有效1无效,只展示有效数据
      }
    ]
  }
)